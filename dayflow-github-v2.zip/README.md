# Dayflow

Schedule app with an AI assistant (Ask tab) that can read text from photos and timetables. Runs on Cloudflare Workers.

## Files in this repository (check these are visible on the FIRST page of the repo)
- `wrangler.toml`  <- must be at the top level, not inside another folder
- `package.json`
- `public/`  (the website)
- `src/`  (the AI server code)

## Deploy
1. Cloudflare dashboard > Workers & Pages > Create > Import a repository > pick this repository.
2. Worker name: `dayflow`. Build command: leave empty. Deploy command: `npx wrangler deploy --config wrangler.toml`. Root directory: `/` (leave as is).
3. After the first deploy: Worker > Settings > Variables and Secrets > Add > type Secret, name `ANTHROPIC_API_KEY`, value = your key from console.anthropic.com > Deploy.
4. Open `https://YOUR-WORKER.workers.dev/api/ask`. `"configured":true` means the assistant is ready.

Never put the API key in any file in this repository.

Optional variables: `ANTHROPIC_CHAT_MODEL`, `ANTHROPIC_MODEL`, `ALLOWED_ORIGINS`.

## Phone app (Capacitor)
Use `public/` as the web folder and set `apiBase` in `public/config.js` to your Worker address (no slash at the end).
